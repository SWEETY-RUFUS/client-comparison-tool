# Client Comparison Tool

A browser-based Excel workbook comparison tool. Workbook processing is performed locally in the browser.

## Output worksheets

- Original client worksheets remain in their original order.
- `PSU` — reusable extract of `Matched_CL_ID`, `PTY_LOCAL_CODE`, and `Source_Client_Sheet` for the client name entered in B2. Rows with blank PTY codes are retained.
- `Force` — reusable extract of `Source_Client_Sheet`, actual `CL_ID`, and `PTY_LOCAL_CODE` for the client name entered in B2.
- `Local Code Logic` — persistent mapping register with `Client_Unique_ID`, `PTY_LOCAL_CODE`, and `Source_Client_Sheet`.
- `_ExtractData` — hidden helper worksheet used by the two extracts.

## Comparison behavior

- Uses the existing reverse-order comparison: earlier client sheets compare against sheets to their right; the last client sheet is the reference.
- Keeps the existing banner/address normalization and match logic.
- Excludes utility worksheets and legacy `Matched` output worksheets from client comparisons.
- Mapping IDs are matched globally against `Matched_CL_ID` in client sheets. `Source_Client_Sheet` is retained as traceability metadata.
- Existing local codes are retained when no nonblank mapped code is available.
- Existing mapping rows with an ID are carried forward; append new mappings below existing entries.

## Files

- `index.html` — application page
- `app.js` — workbook parsing, comparison, extraction, and download
- `style.css` — interface styling

Publish these files in the GitHub Pages repository root. SheetJS is loaded from jsDelivr. The app does not send workbook contents to a server.
